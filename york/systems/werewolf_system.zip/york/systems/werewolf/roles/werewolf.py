ROLE = "werewolf"
